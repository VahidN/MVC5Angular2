/// <reference path="../typings/browser/ambient/es6-shim/index.d.ts" />

import { bootstrap } from '@angular/platform-browser-dynamic';

// Our main component
import { AppComponent } from "./app.component";

bootstrap(AppComponent);