﻿export interface IResult {
    result: boolean;
}