"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var common_1 = require('@angular/common');
var usernameValidators_1 = require('./usernameValidators');
var emailValidators_1 = require('./emailValidators');
var user_service_1 = require('./user.service');
var SignupFormComponent = (function () {
    function SignupFormComponent(_formBuilder, _userService) {
        var _this = this;
        this._formBuilder = _formBuilder;
        this._userService = _userService;
        this.form = _formBuilder.group({
            name: ['', common_1.Validators.compose([
                    common_1.Validators.required,
                    usernameValidators_1.UsernameValidators.cannotContainSpace
                ]),
                function (control) { return _this.nameShouldBeUnique(control); }],
            email: ['', common_1.Validators.compose([
                    common_1.Validators.required,
                    emailValidators_1.EmailValidators.email])],
            password: ['', common_1.Validators.required]
        });
    }
    SignupFormComponent.prototype.onSubmit = function () {
        console.log(this.form.value);
        /*this.form.find('name').setErrors({
            invalidData : true
        });*/
        this._userService.addUser(this.form.value)
            .subscribe(function (user) {
            console.log("ID: " + user.id);
        });
    };
    SignupFormComponent.prototype.nameShouldBeUnique = function (control) {
        var _this = this;
        var name = control.value;
        return new Promise(function (resolve) {
            _this._userService.isUserNameUnique({ "name": name }).subscribe(function (result) {
                resolve(result.result ? null : { 'nameShouldBeUnique': true });
            }, function (error) {
                resolve(null);
            });
        });
    };
    SignupFormComponent = __decorate([
        core_1.Component({
            selector: 'signup-form',
            templateUrl: 'app/users/signup-form.component.html',
            providers: [user_service_1.UserService]
        }), 
        __metadata('design:paramtypes', [common_1.FormBuilder, user_service_1.UserService])
    ], SignupFormComponent);
    return SignupFormComponent;
}());
exports.SignupFormComponent = SignupFormComponent;
//# sourceMappingURL=signup-form.component.js.map